
import 'package:flutter/material.dart';

class ColorConst{
  static const Color reUsedColor = Color(0xff9f97e2);
  static const Color reUsedBackgroundColor = Color(0xff7165d6);
  static const Color reUsedWhiteColor = Colors.white;
  static const Color reUsedBlack54 = Colors.black54;
}