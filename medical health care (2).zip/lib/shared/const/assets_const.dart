class AssetsConst{
  static const String drImages = 'assets/images/doctor nurse.png';
}